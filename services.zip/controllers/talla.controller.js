import{Talla} from '../models/Talla.js' 
export const getTallas=async(req,res)=>{
    try {
        const talla =await Talla.findAll()
         res.json(talla)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const getTalla=async(req,res)=>{
    try {
        const {id}=req.params
        const talla =await Talla.findByPk(id)
        if(!talla)return res.status(404).json({message:"No existe la talla"});
        res.json(talla)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const createTallas=async(req,res)=>{
    const {talla}=req.body
    try {
        const newTalla= await Talla.create({
            talla
        })
        res.json(newTalla)
    } catch (error) {
        return res.status(500).json({mensaje:error.message="Validation error"?"Ya existe el elemento":"Ha ocurrido un error, por favor reintente"});  

    }
}
export const updateTallas=async(req,res)=>{
    try {
    const {id}=req.params
    const {talla}=req.body
    const _talla=await Talla.findByPk(id)
    _talla.talla=talla
    await _talla.save()
    res.json(_talla)
    } catch (error) {
        return res.status(500).json({mensaje:error.message="Validation error"?"Ya existe el elemento":"Ha ocurrido un error, por favor reintente"});  

    }
}
export const deleteTallas=async(req,res)=>{
    const {id}=req.params
    try {
        await Talla.destroy({
            where:{
                id,
            }
        })
        res.sendStatus(204);
    } catch (error) {
        return res.status(500).json({message:error.message});  
    }
}