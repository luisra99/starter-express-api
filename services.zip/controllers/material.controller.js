import{Material} from '../models/Material.js' 
export const getMaterials=async(req,res)=>{
    try {
        const material =await Material.findAll()
         res.json(material)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const getMaterial=async(req,res)=>{
    try {
        const {id}=req.params
        const material =await Material.findByPk(id)
        if(!material)return res.status(404).json({message:"No existe la material"});
        res.json(material)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const createMaterials=async(req,res)=>{
    const {material}=req.body
    try {
        const newMaterial= await Material.create({
            material
        })
        res.json(newMaterial)
    } catch (error) {
        return res.status(500).json({message:error.message});  
    }
}
export const updateMaterials=async(req,res)=>{
    try {
    const {id}=req.params
    const {material}=req.body
    const _material=await Material.findByPk(id)
    _material.material=material
    await _material.save()
    res.json(_material)
    } catch (error) {
        return res.status(500).json({message:error.message});  
    }
}
export const deleteMaterials=async(req,res)=>{
    const {id}=req.params
    try {
        await Material.destroy({
            where:{
                id,
            }
        })
        res.sendStatus(204);
    } catch (error) {
        return res.status(500).json({message:error.message});  
    }
}