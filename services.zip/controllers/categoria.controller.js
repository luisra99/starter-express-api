import{Categoria} from '../models/Categoria.js' 
export const getCategorias=async(req,res)=>{
    try {
        const categorias =await Categoria.findAll()
         res.json(categorias)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const getCategoria=async(req,res)=>{
    try {
        const {id}=req.params
        const categoria =await Categoria.findByPk(id)
        if(!categoria)return res.status(404).json({message:"No existe la categoria"});
        res.json(categoria)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const createCategorias=async(req,res)=>{
    const {categoria}=req.body
    try {
        const newCategoria= await Categoria.create({
            categoria
        })
        res.json(newCategoria)
    } catch (error) {
        return res.status(500).json({mensaje:error.message="Validation error"?"Ya existe el elemento":"Ha ocurrido un error, por favor reintente"});  
    }
}
export const updateCategorias=async(req,res)=>{
    try {
    const {id}=req.params
    const {categoria}=req.body
    const _categoria=await Categoria.findByPk(id)
    _categoria.categoria=categoria
    await _categoria.save()
    res.json(_categoria)
    } catch (error) {
        return res.status(500).json({mensaje:error.message="Validation error"?"Ya existe el elemento":"Ha ocurrido un error, por favor reintente"});  
    }
}
export const deleteCategorias=async(req,res)=>{
    const {id}=req.params
    try {
        await Categoria.destroy({
            where:{
                id,
            }
        })
        res.sendStatus(204);
    } catch (error) {
        return res.status(500).json({message:error.message});  
    }
}