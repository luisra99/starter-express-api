import{Color} from '../models/Color.js' 
export const getColors=async(req,res)=>{
    try {
        const color =await Color.findAll()
         res.json(color)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const getColor=async(req,res)=>{
    try {
        const {id}=req.params
        const color =await Color.findByPk(id)
        if(!color)return res.status(404).json({message:"No existe la color"});
        res.json(color)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const createColors=async(req,res)=>{
    const {color}=req.body
    try {
        const newColor= await Color.create({
            color
        })
        res.json(newColor)
    } catch (error) {
        return res.status(500).json({mensaje:error.message="Validation error"?"Ya existe el elemento":"Ha ocurrido un error, por favor reintente"});  
    }
}
export const updateColors=async(req,res)=>{
    try {
    const {id}=req.params
    const {color}=req.body
    const _color=await Color.findByPk(id)
    _color.color=color
    await _color.save()
    res.json(_color)
    } catch (error) {
        return res.status(500).json({mensaje:error.message="Validation error"?"Ya existe el elemento":"Ha ocurrido un error, por favor reintente"});  
    }
}
export const deleteColors=async(req,res)=>{
    const {id}=req.params
    try {
        await Color.destroy({
            where:{
                id,
            }
        })
        res.sendStatus(204);
    } catch (error) {
        return res.status(500).json({message:error.message});  
    }
}