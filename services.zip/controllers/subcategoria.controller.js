import{SubCategoria} from '../models/SubCategoria.js' 
export const getSubCategorias=async(req,res)=>{
    try {
        const subCategorias =await SubCategoria.findAll()
         res.json(subCategorias)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const getSubCategoria=async(req,res)=>{
    try {
        const {id}=req.params
        const subCategoria =await SubCategoria.findByPk(id)
        if(!subCategoria)return res.status(404).json({message:"No existe la SubCategoria"});
        res.json(subCategoria)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const createSubCategorias=async(req,res)=>{
    const {sub_categoria,id_categoria}=req.body
    try {
        const newSubCategoria= await SubCategoria.create({
            sub_categoria,
            id_categoria
        })
        res.json(newSubCategoria)
    } catch (error) {
        return res.status(500).json({mensaje:error.message="Validation error"?"Ya existe el elemento":"Ha ocurrido un error, por favor reintente"});  
    }
}
export const updateSubCategorias=async(req,res)=>{
    try {
    const {id}=req.params
    const {sub_categoria,id_categoria}=req.body
    const _subCategoria=await SubCategoria.findByPk(id)
    _subCategoria.sub_categoria=sub_categoria
    _subCategoria.id_categoria=id_categoria
    await _subCategoria.save()
    res.json(_subCategoria)
    } catch (error) {
        return res.status(500).json({mensaje:error.message="Validation error"?"Ya existe el elemento":"Ha ocurrido un error, por favor reintente"});   
    }
}
export const deleteSubCategorias=async(req,res)=>{
    const {id}=req.params
    try {
        await SubCategoria.destroy({
            where:{
                id,
            }
        })
        res.sendStatus(204);
    } catch (error) {
        return res.status(500).json({message:error.message});  
    }
}