import{Curvatura} from '../models/Curvatura.js' 
export const getCurvaturas=async(req,res)=>{
    try {
        const curvatura =await Curvatura.findAll()
         res.json(curvatura)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const getCurvatura=async(req,res)=>{
    try {
        const {id}=req.params
        const curvatura =await Curvatura.findByPk(id)
        if(!curvatura)return res.status(404).json({message:"No existe la curvatura"});
        res.json(curvatura)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const createCurvaturas=async(req,res)=>{
    const {curvatura}=req.body
    try {
        const newCurvatura= await Curvatura.create({
            curvatura
        })
        res.json(newCurvatura)
    } catch (error) {
        return res.status(500).json({mensaje:error.message="Validation error"?"Ya existe el elemento":"Ha ocurrido un error, por favor reintente"});  
 
    }
}
export const updateCurvaturas=async(req,res)=>{
    try {
    const {id}=req.params
    const {curvatura}=req.body
    const _curvatura=await Curvatura.findByPk(id)
    _curvatura.curvatura=curvatura
    await _curvatura.save()
    res.json(_curvatura)
    } catch (error) {
        return res.status(500).json({mensaje:error.message="Validation error"?"Ya existe el elemento":"Ha ocurrido un error, por favor reintente"});  

    }
}
export const deleteCurvaturas=async(req,res)=>{
    const {id}=req.params
    try {
        await Curvatura.destroy({
            where:{
                id,
            }
        })
        res.sendStatus(204);
    } catch (error) {
        return res.status(500).json({message:error.message});  
    }
}