import { sequelize } from "../config/database.js";

export const getExist=async(req,res)=>{
    try {
        const existencias =await sequelize.query("SELECT * FROM existencia")
         res.json(existencias[0])
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const getVales=async(req,res)=>{
    try {
        const vales =await sequelize.query("SELECT * FROM vales")
         res.json(vales[0])
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}