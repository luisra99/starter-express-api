import{DataTypes} from 'sequelize'
import{sequelize} from '../config/database.js'

export const Gasto=sequelize.define('gasto',{
    id:{
        type:DataTypes.DATEONLY,
        primaryKey:true,
        autoIncrement:false
    },
    monto:{
        type:DataTypes.INTEGER,
        allowNull: false
    },
    descripcion:{
        type:DataTypes.TEXT,
        allowNull: false
    }
});
