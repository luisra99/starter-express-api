import{ProductoExist} from '../models/ProductoExist.js' 
import {ValeDeVenta} from '../models/ValeDeVenta.js'
import {Producto} from '../models/Producto.js'

export const getProductoExists=async(req,res)=>{
    try {
        const productoExist =await ProductoExist.findAll()
         res.json(productoExist)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const getProductoExist=async(req,res)=>{
    try {
        const {id}=req.params
        const productoExist =await ProductoExist.findByPk(id)
        if(!productoExist)return res.status(404).json({message:"No existe la talla"});
        res.json(productoExist)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const createProductoExist=async(req,res)=>{
    console.log("------------------------------------")
    const {id_categoria,id_sub_categoria,id_local,id_talla,id_color,descripcion,costo,precio,comision,merma_c,total,almacen,area_de_venta}=req.body
    try {
        const id_producto =await Producto.findAll({
            attributes:[id_categoria,id_sub_categoria]
        });
        console.log("------------------------------------")
        console.log(id_producto);
        console.log("------------------------------------")
        const newProductoExist= await ProductoExist.create({
            id_producto,id_local,id_talla,id_color,descripcion,costo,precio,comision,merma_c,total,almacen,area_de_venta
        })
        res.json(newProductoExist)
    } catch (error) {
        return res.status(500).json({message:error.message});  
    }
}
export const updateProductoExist=async(req,res)=>{
    try {
    const {id}=req.params
    const {id_producto,id_local,id_talla,id_color,descripcion,costo,precio,comision,merma_c,total,almacen,area_de_venta}=req.body
    const productoExist=await ProductoExist.findByPk(id)
    productoExist.id_color=id_color
    productoExist.id_local=id_local
    productoExist.id_talla=id_talla
    productoExist.id_producto=id_producto
    productoExist.descripcion=descripcion
    productoExist.costo=costo
    productoExist.precio=precio
    productoExist.comision=comision
    productoExist.merma_c=merma_c
    productoExist.total=total
    productoExist.almacen=almacen
    productoExist.area_de_venta=area_de_venta
    await productoExist.save()
    res.json(productoExist)
    } catch (error) {
        return res.status(500).json({message:error.message});  
    }
}
export const deleteProductoExist=async(req,res)=>{
    const {id}=req.params
    try {
        await ProductoExist.destroy({
            where:{
                id,
            }
        })
        res.sendStatus(204);
    } catch (error) {
        return res.status(500).json({message:error.message});  
    }
}
export const soldProductoExist=async(req,res)=>{
    const {id}=req.params
    const{id_trabajador,fecha,unidades}=req.body
    try {
        const resultadoDeVenta=await Venta(id,id_trabajador,fecha,unidades)
        res.json(resultadoDeVenta)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
const Venta=async(id,worker,fecha,unidades)=>{
    try {
        //Test values
        worker=1;
        fecha="2/2/2022";
        unidades=1;
        //Test values
        var respuesta=0;
        var existencia=2;
        const product=await ProductoExist.findByPk(id)
        const {id_producto,id_local,id_talla,id_color,descripcion,costo,precio,comision,total,almacen,area_de_venta}=product
        const vale= await CrearVale(id_producto,id_local,id_talla,id_color,descripcion,costo,precio,comision,worker,fecha,unidades)
        if(vale!=undefined){
            product.total=total-1;
            product.area_de_venta=area_de_venta-1;
            const resultado=await product.save();
            if(resultado.area_de_venta==0)
            resultado.almacen>1?existencia=1:existencia=0
            respuesta={
                vale,
                existencia
            }
        }
        else{
            respuesta
        }  
        return respuesta
    } 
    catch (error) {
       await res.json(error)
    }
}
const CrearVale=async(id_producto,id_local,id_talla,id_color,descripcion,costo,precio,comision,id_trabajador,fecha,unidades)=>{
    try {
        const importe=unidades*precio;
        const utilidades=unidades*comision;
        const ganancia=importe-utilidades;
        const ganancia_pura=ganancia-unidades*costo;
        const newValeDeVenta= await ValeDeVenta.create({
            id_producto,id_local,id_talla,id_color,descripcion,costo,precio,comision,id_trabajador,fecha,ganancia,importe,unidades,utilidades,ganancia_pura
        })
        return newValeDeVenta
    } 
    catch (error) {
       await console.log(error);
    }
}
