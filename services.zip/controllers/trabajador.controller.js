import{Trabajador} from '../models/Trabajador.js' 
export const getTrabajadores=async(req,res)=>{
    try {
        const trabajador =await Trabajador.findAll()
         res.json(trabajador)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const getTrabajador=async(req,res)=>{
    try {
        const {id}=req.params
        const trabajador =await Trabajador.findByPk(id)
        if(!trabajador)return res.status(404).json({message:"No existe la talla"});
        res.json(trabajador)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const createTrabajador=async(req,res)=>{
    const {direccion,primer_apellido,segundo_apellido,nombre,contacto,salario_base,ci,id_local}=req.body
    try {
        const newTrabajador= await Trabajador.create({
            direccion,primer_apellido,segundo_apellido,nombre,contacto,salario_base,ci,id_local
        })
        res.json(newTrabajador)
    } catch (error) {
        return res.status(500).json({mensaje:error.message="Validation error"?"Ya existe un trabajador con este carnet de identidad":"Ha ocurrido un error, por favor reintente"});  

    }
}
export const updateTrabajador=async(req,res)=>{
    try {
    const {id}=req.params
    const {direccion,primer_apellido,segundo_apellido,nombre,ci,id_local,contacto,salario_base}=req.body
    const trabajador=await Trabajador.findByPk(id)
    trabajador.ci=ci
    trabajador.nombre=nombre 
    trabajador.primer_apellido=primer_apellido
    trabajador.segundo_apellido=segundo_apellido
    trabajador.direccion=direccion
    trabajador.contacto=contacto
    trabajador.salario_base=salario_base
    trabajador.id_local=id_local
    
    await trabajador.save()
    res.json(trabajador)
    } catch (error) {
        return res.status(500).json({mensaje:error.message="Validation error"?"Ya existe un trabajador con este carnet de identidad":"Ha ocurrido un error, por favor reintente"});  

    }
}
export const deleteTrabajador=async(req,res)=>{
    const {id}=req.params
    try {
        await Trabajador.destroy({
            where:{
                id,
            }
        })
        res.sendStatus(204);
    } catch (error) {
        return res.status(500).json({message:error.message});  
    }
}