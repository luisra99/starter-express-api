import{Local} from '../models/Local.js' 
export const getLocals=async(req,res)=>{
    try {
        const local =await Local.findAll()
         res.json(local)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const getLocal=async(req,res)=>{
    try {
        const {id}=req.params
        const local =await Local.findByPk(id)
        if(!local)return res.status(404).json({message:"No existe la talla"});
        res.json(local)
    } catch (error) {
        return res.status(500).json({message:error.message});
    }
}
export const createLocal=async(req,res)=>{
    const {direccion,trabajadores,tipo,nombre}=req.body
    try {
        const newLocal= await Local.create({
            direccion,trabajadores,tipo,nombre
        })
        res.json(newLocal)
    } catch (error) {
        return res.status(500).json({mensaje:error.message="Validation error"?"Ya existe un local con esta direccion":"Ha ocurrido un error, por favor reintente"});  
    }
}
export const updateLocal=async(req,res)=>{
    try {
    const {id}=req.params
    const {direccion,trabajadores,tipo,nombre}=req.body
    const local=await Local.findByPk(id)
    local.direccion=direccion
    local.trabajadores=trabajadores
    local.tipo=tipo
    local.nombre=nombre
    await local.save()
    res.json(local)
    } catch (error) {
        return res.status(500).json({mensaje:error.message="Validation error"?"Ya existe un local con esta direccion":"Ha ocurrido un error, por favor reintente"});  
    }
}
export const deleteLocal=async(req,res)=>{
    const {id}=req.params
    try {
        await Local.destroy({
            where:{
                id,
            }
        })
        res.sendStatus(204);
    } catch (error) {
        return res.status(500).json({message:error.message});  
    }
}