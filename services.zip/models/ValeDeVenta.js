import{DataTypes} from 'sequelize'
import{sequelize} from '../config/database.js'
export const ValeDeVenta=sequelize.define('vale_de_venta',{
    id:{
        type:DataTypes.INTEGER,
        primaryKey:true,
        autoIncrement:true
    },
    fecha:{
        type:DataTypes.DATE,
        allowNull: false
    },
    descripcion:{
        type:DataTypes.TEXT,
        allowNull: false
    },
    costo:{
        type:DataTypes.DECIMAL,
        allowNull: false
    },
    precio:{
        type:DataTypes.DECIMAL,
        allowNull: false
    },
    comision:{
        type:DataTypes.DECIMAL,
        allowNull: false
    },
    unidades:{
        type:DataTypes.INTEGER,
        allowNull: false
    },
    importe:{
        type:DataTypes.DECIMAL,
        allowNull: false
    },
    utilidades:{
        type:DataTypes.DECIMAL,
        allowNull: false
    },
    ganancia:{
        type:DataTypes.DECIMAL,
        allowNull: false
    },
    ganancia_pura:{
        type:DataTypes.DECIMAL,
        allowNull: false
    }
}
);
