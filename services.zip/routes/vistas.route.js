import {Router} from 'express'
import {getExist,getVales} from '../controllers/vistas.controller.js'
const router=Router()

router.get('/view/existencia',getExist)
router.get('/view/vales',getVales)

export default router